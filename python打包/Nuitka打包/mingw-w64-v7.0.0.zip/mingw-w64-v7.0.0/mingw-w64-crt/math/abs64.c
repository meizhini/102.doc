#include <intrin.h>
#include <stdlib.h>

__MINGW_EXTENSION __int64 __cdecl _abs64(__int64 x) {
    return llabs(x);
}
